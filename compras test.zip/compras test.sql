create database compras;
use compras;
create table Mercado (
id int not null auto_increment,
Nome varchar (255),
preco float,
primary key (id)
);
create table musica (
id int not null auto_increment,
Nome varchar (255),
preco float,
primary key (id)
);
create table livros (
id int not null auto_increment,
Nome varchar (255),
autores varchar (255),
preco float,
primary key (id)
);
create table jogos (
id int not null auto_increment,
Nome varchar (255),
plataformas varchar(255),
preco float,
primary key (id)
);
INSERT INTO Mercado (id, nome,preco)
values ('0000011','abacaxi','4.00'),
('0000001','maçâ','4.00'),
('0000002','tomate','5.00'),
('0000003','costela','25.00'),
('0000004','filé','20.00'),
('0000005','bacon','6.00'),
('0000006','bolo','14.00'),
('0000007','pão','4.00'),
('0000008','limão','4.00'),
('0000009','laranja','4.00'),
('0000010','pepino','5.50');
INSERT INTO musica (id, nome,preco)
values ('0010000','Um Homem na estrada','3.00');
INSERT INTO livros (id, nome,autores,preco)
values ('0100000','It A Coisa','Stephen King','74.32'),
('0100001','O Iliminado','Stephen King','41.60'),
('0100002','Dança da Morte','Stephen King','64.90'),
('0100003','O Outsider','Stephen King','43.90'),
('0100004','Jerusalem','Alan Moore','123.05'),
('0100005','Histórias Brilhantes. 10 Hqs De Alan Moore','Alan Moore','59.90'),
('0100006','Mago das Palavras. A Vida Extraordinária de Alan Moore','Alan Moore','61.53'),
('0100007','Do Inferno','Alan Moore','82.71'),
('0100008','Providence Volume 2','Alan Moore','30.89'),
('0100009','V de Vingança','Alan Moore','63.00'),
('0100010','Um Pequeno Assasinato','Alan Moore','68');
INSERT INTO jogos (id, nome,plataformas,preco)
values ('1000000','efootball pes 2020','PS4','119.90');
drop database compras