create database bdbiblio;
use  bdbiblio;
create table manga(
id_manga int not null auto_increment,
autor varchar(255),
título varchar(255),
edição varchar(255),
preço decimal(7,2),
categoria varchar(255),
primary key (id_manga)
);
create table livro(
id_livro int not null auto_increment,
autor varchar(255),
título varchar(255),
edição varchar(255),
preço decimal(7,2),
categoria varchar(255),
primary key(id_livro)
);
create table dvd(
id_dvd int not null auto_increment,
título varchar(255),
preço decimal(7,2),
categoria varchar(255),
primary key(id_dvd)
);
create table cliente(
id_cliente int not null auto_increment,
nome varchar(255),
cartãodecredito int,
primary key (id_cliente)
);
insert into manga
(autor, título, edição, preço, categoria)
values 
('Nakaba Suzuki', 'Nanatsu No Taizai', '1', '41.34', 'Shounen'),
('Nakaba Suzuki', 'Nanatsu No Taizai', '2', '19.90', 'Shounen'),
('Nakaba Suzuki', 'Nanatsu No Taizai', '3', '11.30', 'Shounen'),
('Nakaba Suzuki', 'Nanatsu No Taizai', '4', '11.61', 'Shounen'),
('Nakaba Suzuki', 'Nanatsu No Taizai', '5', '11.61', 'Shounen'),
('Nakaba Suzuki', 'Nanatsu No Taizai', '6', '12.90', 'Shounen'),
('Nakaba Suzuki', 'Nanatsu No Taizai', '7', '20.00', 'Shounen');
insert into livro
(autor, título, edição, preço, categoria)
values
('Marco Abreu', 'As Crônicas de Arian: Livro 1 O Guardião Sem Memórias', 'única', '14.90', 'Ficção'),
('H. P. Lovecraft', 'Mestres do Terror', 'única', '59.90', 'Terror'),
('Shirley Jackson', 'A assombração da Casa da Colina eBook Kindle', 'única', '33.92', 'Horror'),
('Mary Shelley', 'Frankenstein ou o Prometeu moderno', '2', '36.37', 'Terror'),
('Stephen King', 'Joyland', 'única', '27.96', 'Mistério'),
('Stephen King', 'O iluminado', 'única', '58.02', 'Drama'),
('Stephen King', 'O cemitério', 'única', '49.79', 'Terror');
insert into dvd
(título, preço, categoria)
values
("Shazam", "41.52", "Super Herói"),
("Star Wars Os Ultimos Jedi", "29.90", "Ficção Científica"),
("Malévola Dona do Mal ", "30.90", "Fantasia"),
("Frozen 2", "29.90", "Fantasia"),
("Sonic The Hedgehog", "119.90", "Adaptação de jogo"),
("AVES DE RAPINA: ARLEQUINA E SUA EMANCIPAÇÃO FANTABULOSA", "69.90", "Adaptação de Quadrindos");
insert into cliente
(nome, cartãodecredito)
values
("Mauricio Silva", "5"),
("Wendel Bezerra", "6"),
("Jair Brandão", "7"),
("Ana silva", "8"),
("Joâo Souza", "9"),
("Albert Einstein", "4"),
("Guilherme Briggs", "3"),
("Bruno Mota", "2"),
("Carlos Chagas", "1");
drop database bdbiblio;