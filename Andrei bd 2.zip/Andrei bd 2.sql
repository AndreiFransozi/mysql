create database cidade;
use cidade;
create table cidade(
	id_cidade int not null auto_increment,
    nome varchar(100),
    populacao int,
    primary key(id_cidade)
    );
    
    create table cidadao(
    id_cidadao int not null auto_increment,
    id_cidade int,
    nome varchar(100),
    dataNasc date,
    primary key(id_cidadao),
    foreign key(id_cidade) references cidade(id_cidade)
    );
    create procedure insere_cidade(In nomeP varchar(100), in populacaop int)
    begin
    insert into cidade (nome,populacao) values (nomeP, populacaoP);
    end $
    delimiter $
call insere_cidade('joaçaba', 30118);
call insere_cidade('Luzerna', 5700);
call insere_cidade('Lacerdopolis', 2199);

    