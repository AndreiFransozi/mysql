create database dbCidade27maio;
use dbCidade27maio;

create table cidade(
	id_cidade int not null auto_increment,
	nome varchar(100),
    populacao int,
    primary key(id_cidade)
);

create table cidadao(
	id_cidadao int not null auto_increment,
    id_cidade int,
    nome varchar(100),
    dataNasc date,
    primary key(id_cidadao),
    foreign key(id_cidade) references cidade(id_cidade)
);

--  ----------------------------------------------
delimiter $
create procedure insere_cidade(in nomeP varchar(100), in populacaoP int)
begin
	insert into cidade (nome,populacao) values (nomeP, populacaoP);
end $
delimiter ;

call insere_cidade('Joaçaba', 30118);
call insere_cidade('Luzerna', 5600);
call insere_cidade('Lacerdópolis', 2199);
call insere_cidade('Capinzal', 20769);

--  ----------------------------------------------
delimiter $
create procedure insere_cidadao(in nomeP varchar(100), in dataNascP date, in cidade varchar(100) )
begin
	declare idcity int;
    -- buscar o id da cidade com base no nome => parâmetro cidade
    set idcity =  (select id_cidade from cidade where nome = cidade);
	-- inserir um cidadão na tabela com os parâmetros e o idcity
	insert into cidadao (id_cidade,nome, dataNasc) values (idcity,nomeP,dataNascP);
end $
delimiter ;

call insere_cidadao('Regina', '2000-02-02', 'Joaçaba');
call insere_cidadao('Diogo', '2001-01-01', 'Joaçaba');
call insere_cidadao('Felipe', '2003-03-03', 'Joaçaba');
call insere_cidadao('Ricardo', '2004-04-04', 'Luzerna');
call insere_cidadao('Helena', '2001-05-05', 'Lacerdópolis');
call insere_cidadao('Julio', '2003-06-06', 'Luzerna');

delimiter $
create procedure  listarCidades()
begin
	select nome as Cidade, populacao as População from cidade;
end $
delimiter ;

call listarCidades();


delimiter $
create procedure listarCidadaos()
begin
	select cidadao.nome as Cidadão, dataNasc as 'Data de Nascimento', cidade.nome as Cidade 
    from cidade inner join cidadao on (cidade.id_cidade = cidadao.id_cidade);
end $
delimiter ;

call listarCidadaos();


delimiter $
create procedure excluirCidade(in cidadeP varchar(100))
begin
	declare idcity int;
    set idcity = (select id_cidade from cidade where nome = cidadeP);
	delete from cidade where id_cidade = idcity;
end $
delimiter ;

call excluirCidade('Capinzal');

delimiter $
create procedure excluirCidadao(in cidadaoP varchar(100))
begin
	declare idpessoa int;
    declare idcity int;
    set idpessoa = (select id_cidadao from cidadao where nome = cidadaoP);
    set idcity = (select id_cidade from cidadao where nome = cidadaoP);
    delete from cidadao where id_cidadao = idpessoa;
    update cidade set populacao = populacao - 1 where id_cidade = idcity;
end $
delimiter ;

call excluirCidadao('Ricardo');

    
    
    