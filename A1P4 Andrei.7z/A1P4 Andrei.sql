-- Andrei Augusto Fransozi, Alison de Campos Glasenapp e Vinícius Leinate Porto --
create database AndreiA1p4;
use AndreiA1p4;
create table Imovel(
id int not null auto_increment,
tipo varchar (50),
situacao varchar(50),
endereco varchar(255),
bairro varchar(80),
cidade varchar(80),
estado varchar(2),
descricao varchar(255),
nomePropretario varchar(80),
cpfPropretario varchar(20),
fonePropretario varchar(50),
primary key(id)
);
create table  clienteUsuario(
id int,
nome varchar(80),
fone varchar(50),
cpf varchar(20),
nomeFiador varchar(80),
foneFiador varchar(50),
cpfFiador varchar(20),
primary key(id)
);
create table corretor(
id int,
nome varchar(80),
cpf varchar(20),
foneCelular varchar(50),
salarioBase float,
salarioTotal float,
primary key(id)
);
create table Alugel(
id int,
dataAluguel date,
valorAluguelInicial Float,
valorAluguelFinal Float,
valorImobiliaria float,
dataDisponivelAluguel Date,
numContrato int,
formaPagto varchar(100),
primary key(id),
foreign key(imovel_id) references imovel(id),
foreign key(clienteUsuario_id) references clienteUsuario(id)
);
create table comissaoAluguel(
id int,
valorComissao float,
foreign key (corretor_id) references corretor(id),
foreign key (aluguel_id) references aluguel(id)
);

delimiter $
create procedure incluir_imoveis(in tipos 



drop database AndreiA1p4;