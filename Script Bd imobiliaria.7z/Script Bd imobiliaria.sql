-- resolucao sobre programação em DB--
-- acadêmicos Vinicius Leinate Porto, Andrei Augusto Fransozi ,Alisson de Campos Glasenapp --
create database trabalho17junh2020;
use trabalho17junh2020;
create table Imovel(
id int not null auto_increment,
tipo Varchar(50),
situacao Varchar(45),
dataConstrucao Date,
areaTotal float,
endereco Varchar(255),
bairro varchar(80),
cidade varchar(80),
estado varchar(2),
descricao varchar(255),
primary key (id)
);

create table ClienteUsuario(
id int not null auto_increment,
nome Varchar(80),
fone Varchar(50),
cpf Varchar(20),
primary key(id)
);

create table Venda(
id int not null auto_increment,
imovel_id int,
clienteUsuario_id int,
dataVenda date,
valorVendaincial float,
valorVendaFinal float, 
valorImobiliaria float,
dataDisponivelvenda date,
numContrato int,
formaPagto Varchar(100),
primary key(id),
foreign key(imovel_id) references imovel(id),
foreign Key(clienteUsuario_id) references clienteUsuario(id)
);

create table Funcionario(
id int not null auto_increment,
nome varchar (80),
cpf varchar(45),
foneCelular Varchar(45),
salarioTotal float,
primary key(id)
);

create table ComissaoVenda(
id int not null auto_increment,
valorComissao float,
funcionario_id int,
venda_id int,
primary key(id),
foreign key(funcionario_id)references funcionario(id),
foreign Key(venda_id)references Venda(id)
);

delimiter $
create procedure incluir_Imovel (in tipox Varchar(50), in situacaox Varchar(45), in dataConstrucaox Date,in areaTotalx float,in enderecox Varchar(255),in bairrox varchar(80),in cidadex varchar(80),in estadox varchar(2),in descricaox varchar(255))
begin 
	insert into Imovel(tipo,situacao,dataConstrucao,areaTotal,endereco,bairro,cidade,estado,descricao) values
    (tipox,situacaox,dataConstrucaox,areaTotalx,enderecox,bairrox,cidadex,estadox,descricaox);

end $
delimiter ;
call incluir_imovel("apartamento","indisponivel","2007.07.13",300,"end1","bairro1","cidade1","SC","desc1");
call incluir_imovel("casa","indisponivel","2000.08.14",400,"end2","bairro2","cidade2","SC","desc2");
call incluir_imovel("apartamento","indisponivel","2007.07.11",340,"end3","bairro3","cidade3","SC","desc3");
call incluir_imovel("casa","indisponivel","2000.08.16",306,"end4","bairro4","cidade4","SC","desc4");
call incluir_imovel("apartamento","indisponivel","2008.07.13",500,"end5","bairro5","cidade5","MG","desc5");
call incluir_imovel("casa","indisponivel","2006.08.14",400,"end6","bairro6","cidade6","SC","desc6");
call incluir_imovel("apartamento","indisponivel","2004.07.11",340,"end7","bairro7","cidade7","SC","desc7");
call incluir_imovel("casa","indisponivel","2010.08.16",380,"end8","bairro8","cidade8","SC","desc8");
call incluir_imovel("apartamento","indisponivel","2017.07.11",100,"end9","bairro9","cidade9","SC","desc9");
call incluir_imovel("casa","indisponivel","2023.08.16",206,"end10","bairro10","cidade10","SC","desc10");
delimiter $

create procedure incluir_ClienteUsuario(in nome Varchar(80), in fone Varchar(50), in cpf Varchar(20))
	insert into Imovel(nome,fone,cpf) values
    (nomex,fonex,cpfx);
end $
delimiter ;
call incluir_ClienteUsuario("Pedro",111111111,11111111111);
call incluir_ClienteUsuario("Ana",222222222,22222222222);
call incluir_ClienteUsuario("Gian",333333333,33333333333);
call incluir_ClienteUsuario("Gabriela",444444444,44444444444);
call incluir_ClienteUsuario("Giovana",555555555,55555555555);


create procedure incluir_ClientePropretario(in nome Varchar(80), in fone Varchar(50), in cpf Varchar(20))
	insert into Imovel(nome,fone,cpf) values
    (nomex,fonex,cpfx);
end $
delimiter ;
call incluir_ClientePropretario("Paulo",666666666,66666666666);
call incluir_ClientePropretario("Andressa",777777777,77777777777);
call incluir_ClientePropretario("Alex",888888888,88888888888);
call incluir_ClientePropretario("Gabrriel",999999999,99999999999);
call incluir_ClientePropretario("Gian",101010101,10101010101);

create procedure incluir_Funcionario(in nome varchar (80), in cpf varchar(45), in foneCelular Varchar(45), in salarioTotal float)
	insert into funcinario(nome,cpf,foneCelular,salarioTotal) values
    (nomex,cpfx,foneCelularx,salarioTotalx);
end $
delimiter ;
call incluir_Funcionario ("Aline",11111111112,111111112,3000);
call incluir_Funcionario ("Aloísio",11111111113,111111113,3050);
call incluir_Funcionario ("Bruna",11111111114,111111114,3100);
call incluir_Funcionario ("Bianca",11111111115,111111115,3330);
call incluir_Funcionario ("Mario",11111111116,111111116,3350);
call incluir_Funcionario ("Luiz",11111111117,111111117,3390);
call incluir_Funcionario ("Gustavo",11111111118,111111118,3500);
call incluir_Funcionario ("Fernado",11111111119,111111119,3460);
call incluir_Funcionario ("Breno",11111111120,111111120,4500);
call incluir_Funcionario ("Camila",11111111121,111111121,5000);

create procedure venda_imoveis(in imovel_id int, in clienteUsuario_id int, in dataVenda date, in valorVendaincial float, in valorVendaFinal float, in valorImobiliaria float, in dataDisponivelvenda date, in numContrato int, in formaPagto Varchar(100))
insert into Imovel(imovel_id,clienteUsuario_id,dataVenda,valorVendaincial,valorVendaFina,valorImobiliaria,dataDisponivelvenda,numContrato,formaPagto)
  (imovel_idx,clienteUsuario_idx,dataVendax,valorVendaincialx,valorVendaFinax,valorImobiliariax,dataDisponivelvendax,numContratox,formaPagtox)
end $
delimiter ;
call venda_imoveis(111111122,111111122,8/15/2010,1000,2000,1500,8/18/2015,111111122,dinheiro);
call venda_imoveis(111111123,111111123,8/16/2010,1000,2000,1500,8/18/2016,111111123,dinheiro);
call venda_imoveis(111111124,111111124,8/17/2010,1000,2000,1500,8/18/2014,111111124,dinheiro);
call venda_imoveis(111111125,111111125,8/15/2010,1000,2000,1500,8/18/2013,111111125,dinheiro);
call venda_imoveis(111111126,111111126,8/15/2010,1000,2000,1500,8/18/2012,111111126,dinheiro);
call venda_imoveis(111111127,111111127,8/15/2010,1000,2000,1500,8/18/2011,111111127,dinheiro);

create procedure registre_venda(in clienteUsuario_id int, in dataVenda date,in valorVendaFinal float, in valorImobiliaria float, in dataDisponivelvenda date, in numContrato int, in formaPagto Varchar(100))
insert into Imovel(clienteUsuario_id,dataVenda,valorVendaincial,valorVendaFina,valorImobiliaria,dataDisponivelvenda,numContrato,formaPagto)
  (clienteUsuario_idx,dataVendax,valorVendaincialx,valorVendaFinax,valorImobiliariax,dataDisponivelvendax,numContratox,formaPagtox)
end $
delimiter ;



drop database trabalho17junh2020;
