create database cadastro1;
use cadastro1
