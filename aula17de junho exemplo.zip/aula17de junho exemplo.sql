create database BdTestview_17jun2020;
use BdTestview_17jun2020;
create table funcionario(
	id int not null auto_increment,
	nome varchar(100),
    email varchar(100),
    salario float,
    fone varchar(80),
    primary key(id)
);
create view view_funcionario
as select nome,salario,email from funcionario;

insert into view_funcionario (nome,salario,email) values
	("Rodrigo",1000.00,"rodrigo@gmail.com"),
	("Maria Luiza",5000.00,"maria.luiza@gmail.com"),
	("Ana Paula",8000.00,"ana.paula@gmail.com"),
	("Beatriz",14500.00,"beatriz@gmail.com");
alter view view_funcionario
as select nome, salario, email from funcionario
	update set email = "ricardo@gmail.com"
	where nome = "Ricardo";

	update set email = "regina@gmail.com"
	where nome = "Regina";

	update set email = "Helena@gmail.com"
	where nome = "Helena";
	
    update set email = "diogo@gmail.com"
	where nome = "Diogo";

select * from view_funcionario
