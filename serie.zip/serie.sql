create database series;
use series;
create table series(
id_series int not null auto_increment,
titulo varchar(255),
tipo varchar(255),
temporada int,
episodios int,
episodios_assistidos int,
primary key(id_series)
);
insert into series
(titulo, tipo, temporada, episodios, episodios_assistidos)
values
("Bonding", "Humor Ácido", "1", "7", "7"),
("Arrow", "Super Herói", "8", "170", "3"),
("Black Lightning", "Super Herói", "3", "45", "4"),
("Irmandade", "Drama", "1", "8", "0"),
("Dc's Legends of tomorow", "Super Herói", "5", "82", "82"),
("Gotham", "Super Herói", "5", "100", "92"),
("Harley Quinn", "Super Herói", "2", "26", "14"),
("Star Girl", "Super Herói", "1", "11", "0"),
("Level E", "Anime Drama", "1", "13", "13"),
("Super Girl", "Super Herói", "5", "106", "42"),
("Mostro do Pântano", "Super Herói", "1", "10", "1"),
("The Big Bang Theory", "Comédia", "12", "279", "25"),
("Flash", "Super Herói", "6", "133", "5"),
("The Good Place", "Comédia", "4", "50", "50"),
("Titans", "Super Herói", "2", "24", "13"),
("Watchmen", "Super Herói", "1", "9", "0"),
("Batwoman", "Super Herói", "1", "20", "1");
drop database series