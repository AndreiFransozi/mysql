create database provalivro;
use provalivro;
create table produto(
id int not null auto_increment,
nome varchar(100),
preco float,
estoque int,
primary key(id)
);
insert into produto
(id, nome, preco, estoque)
values
('1', 'coca', '15', '3'),
('2', 'chocolate', '4', '4'),
('3', 'pão', '15', '2');
Delimiter $
create procedure prodMaisCaroMaisBaratoEstoque(out pmaiscaro float,
											   out pmaisbarato float,
											   out numprodvendidos int)
begin
	select max(preco) into pmaiscaro from produto;
    select min(preco) into pmaisbarato from produto;
    select count(*) into numprodvendidos from produto;
    end $
Delimiter ;