create database questão3;
use questão3;
create table produto(
id int not null auto_increment,
nome varchar(100),
preco float,
estoque int,
primary key(id)
);
insert into produto (nome,preco,estoque)
values ('livro',15.00,15),
('revista',15.06,15),
('jornall',15.01,15);
delimiter $$
create procedure prodMaiscaroMaisBaratoEstoque (out pmaiscaro float,
												out pmaisbarato	float,			
                                                out numprodvendidos int)
begin
	select max(preco) into pmaiscaro from produto;
    select min(preco) into pmaisbarato from produto;
    select count(*) into numprodvendidos from produto;
end $$
delimiter ;
call prodMaiscaro

drop database questão3;