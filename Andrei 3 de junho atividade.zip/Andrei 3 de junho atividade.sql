create database pessoa;
use pessoa; 
create table cliente(
	id int not null auto_increment,
    nome varchar(100),
    endereco varchar(100) ,
    telefone varchar(100),
    primary key(id)
);
create table fornecedor(
	id int not null auto_increment,
    nome varchar(100),
    endereco varchar(100) ,
    telefone varchar(100),
    primary key(id)
);
create table funcionario(
	id int not null auto_increment,
    nome varchar(100),
    endereco varchar(100) ,
    telefone varchar(100),
    primary key(id)
);
create table vendedor(
	id int not null auto_increment,
    nome varchar(100),
    endereco varchar(100) ,
    telefone varchar(100),
    primary key(id)
);
delimiter $
create procedure insere_pessoa(int tipo varchar (4), in nome varchar(100), in endereco varchar(100),in telefone varchar(100))
begin
	if (tipo) is null then
    select 'informe o tipo';
    if (nome) is null then
       select 'O nome não foi  inserido';
	
create procedure tipo1()
begin
	declare funcao varchar;
    begin
		when funcao = 'cli' then insert into  (nome, endereco, telefone) Values
								(nomePessoa, enderecoPessoa, telefonePessoa),
			select 'cliente'
		when funcao = 'for' then insert into  (nome, endereco, telefone) Values
								(nomePessoa, enderecoPessoa, telefonePessoa),
			select 'fornecedor'
		when funcao = 'fun' then insert into (nome, endereco, telefone) Values
								(nomePessoa, enderecoPessoa, telefonePessoa),
			select 'fucionario'
		when funcao = 'ven' then insert into vendedor(nome, endereco, telefone) Values
								(nomePessoa, enderecoPessoa, telefonePessoa),
			select 'vendedor'
		when funcao = null then
        select 'o tipo apresentado é invalido'
    end case;
delimiter $
drop database pessoa;