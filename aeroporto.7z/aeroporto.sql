create database aeroporto;
use aeroporto;
create table Aviao(
codAviao int not null auto_increment,
nroserie Varchar (10),
modelo varchar (100),
capacidade int,
primary key(codAviao)
);
create table partida(
id_partida int not null,
hora_partida time,
data_partida date,
aviao_id int,
aeroporto_partida varchar(255),
primary key(id_partida)
);
create table chegada(
id_chegada int not null,
hora_chegada time,
data_chegada date,
aviao_id int,
aeroporto_chegada varchar(255),
primary key(aviao_id)
);
insert into Aviao
(nroserie, modelo, capacidade)
values
("PR-AZA", "Boeing 737-400F", "800"),
("PR-AZB", "Embraer E-190", "970"),
("PR-AZC", "Embraer E-195", "450"),
("PR-AZD", "Embraer E-190", "600"),
("PR-AZE", "Airbus A330", "560"),
("PR-AZF", "Airbus A330-900neo", "620"),
("PR-AZG", "Embraer E-195 E2", "300"),
("PR-AZH", "Airbus A330-900neo", "200"),
("PR-AZI", "Airbus A330-900neo", "240"),
("PR-AZJ", "Airbus A330-900neo", "320"),
("PR-AZK", "Airbus A330-900neo", "700"),
("PR-AZL", "Airbus A330-900neo", "780");
insert into partida
(id_partida, hora_partida, data_partida, aviao_id, aeroporto_partida)
values
("0001", "6:00", "2020-07-17", "1", "Carlos Alberto da Costa Neves"),
("0002", "11:00", "2019-07-17", "2", "O Aeroporto Carlos Alberto da Costa Neves"),
("0003", "11:30", "2018-07-17", "3", "Guarulhos"),
("0004", "8:20", "2018-06-17", "4", "João Wincler"),
("0005", "9:30", "2018-06-15", "5", "Afonso Pena"),
("0006", "10:30", "2018-06-12", "6", "Dimorvan Carraro"),
("0007", "11:02", "2018-06-10", "7", "Serafim Enoss Bertaso"),
("0008", "11:45", "2018-06-09", "8", "Aeroporto Regional de Blumenau");
insert into chegada
(id_chegada, hora_chegada, data_chegada, aviao_id, aeroporto_chegada)
values
("0001", "11:00", "2020-07-17", "1", "Carlos Alberto da Costa Neves"),
("0002", "11:50", "2020-07-16", "2", "Afonso Pena"),
("0003", "11:40", "2020-07-15", "3", "Carlos Alberto da Costa Neves"),
("0004", "12:00", "2020-07-14", "4", "Afonso Pena"),
("0005", "12:05", "2020-07-13", "5", "Carlos Alberto da Costa Neves"),
("0006", "12:10", "2020-07-12", "6", "Afonso Pena"),
("0007", "12:09", "2020-07-11", "7", "Serafim Enoss Bertaso"),
("0008", "12:40", "2020-07-10", "8", "Afonso Pena");

