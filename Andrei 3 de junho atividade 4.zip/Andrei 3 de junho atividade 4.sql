create database divida;
use divida;
create table divida(
id int,
ano int,
valor_divida Decimal(0.1)
);
delimiter $
create procedure fatorial3(in valor int)
begin 
declare fator int default 1;
declare i int default 1;

calculo: repeat
set fator = fator * i;
set i = i+1;
until (i > 100) end repeat calculo ;
select fator;
end $
delimiter ;
drop database divida;