create database amazon;
use amazon;
create table autor(
id_autor int not null auto_increment,
nome_autor varchar(255),
primary key(id_autor)
);
create table livro(
id_livro int not null auto_increment,
titulo varchar(255),
preço float,
edição varchar(10),
primary key(id_livro)
);
create table usuario(
id_usuario int not null auto_increment,
nome varchar(255),
cpf varchar (20),
primary key (id_usuario)
);
create table venda(
id_venda int not null auto_increment,
data_venda date,
hora_venda time,
primary key(id_venda)
);
insert into autor
(id_autor, nome_autor)
values
('000001', 'Alan Moore'),
('000002', 'Stan Lee'),
('000003', 'Frank Miller'),
('000004', 'Mauricio de Sousa');
insert into livro
(id_livro, titulo, preço, edição)
values
('100001', 'Watchmen', '94.50', 'definitiva'),
('100002', 'Amazing Fanatasy', '50.00', '15'),
('100003', 'Batman Ano 1', '70.77', 'única'),
('100004', 'Turma da Mônica Jovem Tesouro Verde', '34.90', 'única'),
('100005', 'Sin City A Cidade do Pecado', '75.90', 'única'),
('100006', 'Sin City O Assassino Amarelo', '79.90', 'única'),
('100007', 'Sin City De Volta ao Inferno', '79.30', '2');
insert into usuario
(id_usuario, nome, cpf)
values
('200000', 'Ana', '000.000.000-00');
insert into venda
(id_venda, data_venda, hora_venda)
values
('300000', '2020/07/20', '23:00');
insert into usuario
(id_usuario, nome, cpf)
values
('200001', 'Ana', '000.000.000-01');
select titulo, preço from livro;
create table mangá(
id_mangá int not null auto_increment,
titulo varchar(255),
autor varchar(255),
desenhista varchar(255),
editora varchar(255),
volume varchar(15),
preço float,
primary key(id_mangá)
);
insert into mangá
(id_mangá, titulo, autor, desenhista, editora, volume, preço)
values
('400000', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '1', '39.90'),
('400001', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '2', '39.90'),
('400002', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '3', '39.90'),
('400003', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '4', '39.90'),
('400004', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '5', '39.90'),
('400005', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '6', '39.90'),
('400006', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '7', '39.90'),
('400007', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '8', '39.90'),
('400008', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '9', '39.90'),
('400009', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '10', '39.90'),
('400010', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '11', '39.90'),
('400011', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '12', '39.90'),
('400012', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '13', '39.90'),
('400013', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '14', '39.90'),
('400014', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '15', '39.90'),
('400015', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '16', '39.90'),
('400016', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '17', '39.90'),
('400017', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '18', '39.90'),
('400018', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '19', '39.90'),
('400019', 'Slam Dunk', 'Takehiko Inoue', 'Takehiko Inoue', 'Panini', '20', '39.90');
insert into usuario
(id_usuario, nome, cpf)
values
('200002', 'joão', '000.000.000-02'),
('200003', 'joana', '000.000.000-03'),
('200004', 'jackson', '000.000.000-04'),
('200005', 'Pedro', '000.000.000-05'),
('200006', 'joaquim', '000.000.000-06'),
('200007', 'Gabriel', '000.000.000-07'),
('200008', 'Gabriela', '000.000.000-08'),
('200009', 'Giovana', '000.000.000-09'),
('200010', 'Gabrieli', '000.000.000-10'),
('200011', 'Vanderlei', '000.000.000-11'),
('200012', 'jamau', '000.000.000-12'),
('200013', 'Julia', '000.000.000-13'),
('200014', 'Karina', '000.000.000-14'),
('200015', 'Cassia', '000.000.000-15'),
('200016', 'Ash', '000.000.000-16'),
('200017', 'Brock', '000.000.000-17'),
('200018', 'Misty', '000.000.000-18'),
('200019', 'Salomão', '000.000.000-19'),
('200020', 'Henry', '000.000.000-20'),
('200021', 'Bruce', '000.000.000-21'),
('200022', 'jason', '000.000.000-22'),
('200023', 'Dick', '000.000.000-23'),
('200024', 'Artur', '000.000.000-24'),
('200025', 'poliana', '000.000.000-25'),
('200026', 'pamela', '000.000.000-26'),
('200027', 'paola', '000.000.000-27'),
('200028', 'otavio', '000.000.000-28'),
('200029', 'mateus', '000.000.000-29'),
('200030', 'Lebron', '000.000.000-30'),
('200031', 'matheus', '000.000.000-31'),
('200032', 'michael', '000.000.000-32'),
('200033', 'igor', '000.000.000-33'),
('200034', 'Diana', '000.000.000-34'),
('200035', 'Larry', '000.000.000-35'),
('200036', 'Larissa', '000.000.000-36'),
('200037', 'Britta', '000.000.000-37'),
('200038', 'Jeff', '000.000.000-38'),
('200039', 'Troy', '000.000.000-39'),
('200040', 'Abed', '000.000.000-40'),
('200041', 'shirley', '000.000.000-41'),
('200042', 'pierce', '000.000.000-42'),
('200043', 'annie', '000.000.000-43'),
('200044', 'Hakim', '000.000.000-44'),
('200045', 'ruby', '000.000.000-45'),
('200046', 'Rachel', '000.000.000-46'),
('200047', 'Megan', '000.000.000-47'),
('200048', 'Drake', '000.000.000-48'),
('200049', 'josh', '000.000.000-49'),
('200050', 'Afonso', '000.000.000-50'),
('200051', 'Carla', '000.000.000-51'),
('200052', 'Carlos', '000.000.000-52'),
('200053', 'Hiromi', '000.000.000-53'),
('200054', 'Jessie', '000.000.000-54'),
('200055', 'James', '000.000.000-55'),
('200056', 'Jane', '000.000.000-56');
select id_usuario, nome, cpf from usuario
drop database amazon