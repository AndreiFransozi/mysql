CREATE DATABASE LOCADORACARRO;
USE LOCADORACARRO;
CREATE TABLE Pessoa(
    ID_Pessoa integer PRIMARY KEY AUTO_INCREMENT,
    Nome varchar(255),
    Endereco varchar(255),
    Cidade varchar(255)
);
CREATE TABLE Carro(
    ID_Carro integer PRIMARY KEY AUTO_INCREMENT,
    Nome varchar(255),
    Marca varchar(255),
    ID_Pessoa integer,
    CONSTRAINT fk_PesCarro FOREIGN KEY (ID_Pessoa) REFERENCES Pessoa (ID_Pessoa)
);
insert INTO Pessoa
(Nome, Endereco, Cidade)
VALUES
("ANDREI", "REAL", "FORTALEZA");
INSERT INTO Carro
(Nome, Marca)
  VALUES
  ("ANA", "LOCAL");
drop DATABASE DENTISTA