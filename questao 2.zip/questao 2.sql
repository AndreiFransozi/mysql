create database questão2;
use questão2;
create table produto(
id int not null auto_increment,
nome varchar(100),
preco float,
estoque int,
primary key(id)
);

delimiter $
create procedure retorna_preco (in nome varchar(100), in preco float, in estoque int)
begin
	insert into preco(nome,preco,estoque) values
    (nomex,precox,estoquex);
end $
delimiter ;
insert into produto (nome,preco,estoque)
values ('livro',15.00,15),
('revista',15.00,15),
('jornall',15.00,15);
select MIN(value(preco)) AS "Menor preco";
select Max(value(preco)) AS "Maior preco"
from produto;
drop database questão2;
