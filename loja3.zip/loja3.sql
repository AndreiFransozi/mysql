create database cl;
use cl;
create table loja(
id_loja int not null auto_increment,
nome_fantasia varchar(255),
area_atuante varchar(255),
primary key (id_loja)
);
create table cliente(
id_cliente int not null auto_increment,
nome varchar(255),
dataNasc date,
Residencia varchar(255),
primary key (id_cliente)
);
create table vendedor(
id_vendedor int not null auto_increment,
nome varchar(255),
primary key (id_vendedor)
);
create table venda(
id_venda int not null auto_increment,
dataVenda date,
valor_venda float,
primary key (id_venda)
);
insert into loja
(nome_fantasia, area_atuante)
values
('Amora', 'Alimentação'),
('Ansi', 'tecnologia'),
('Posi', 'tecnologia');
insert into cliente
(nome,dataNasc,Residencia)
values
('Ana','2000-03-30','resid1'),
('Douglas','2000-03-20','resid2'),
('Antonio','1970-04-16','resid3'),
('Gabriel','1990-11-25','resid4');
insert into vendedor
(nome)
values
('Hugo'),
('Heitor'),
('Bruno'),
('Breno'),
('Gustavo'),
('Rafaela'),
('Gabriela');


drop table venda