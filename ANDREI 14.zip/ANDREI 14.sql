delimiter $
create procedure fatorial01(in valor int)
begin
	declare fator int default 1;
	declare i int default 1;
    
    calculo: LOOP
    set fator = fator * i;
    set i = i +1;
    if (i>valor) then
    LEAVE CALCULO
    end if;
    end LOOP CALCULO;
    select fator;
    end $
    delimiter ;
    
    call fatorial01(2);
    call fatorial01(3);
    call fatorial01(4);
    
    delimiter $
    create procedure fatorial02(in valor int)
    begin
    declare fator int default 1;
    declare i int default 1;
    
    calculo: while (i <= valor) DO
    