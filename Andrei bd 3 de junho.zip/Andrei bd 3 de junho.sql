use database BDCidade27maio
delimiter $
create procedure decisao1(in x float, in y  float)
begin
	declare soma float;
    set soma = x + y ;
if (soma > 10) then
	select 'Soma é maior que 10!';
end if;

end $
delimiter ;

call decisao1(4,8);
call decisao1(4,4);


delimiter $
create procedure decisao3();
begin
if (select nome from produto where estoque >50) is null then
	select 'Não há produto com estoque maior que 50 unidades';
end if;
delimiter $;
call decisao5()
delimiter $
create procedure decisao4(in x float, in y float)
begin
	declare soma float;
    set soma = x + y;
    
    if (soma > 10) then
		select 'soma é maior que 10.';
        elseif (soma = 10) then
        select 'soma é igual que 10.';
end if;
end $
delimiter ;

call decisao4(4,6);
call decisao4(5,10);

delimiter $
create procedure decisao5(in x float, in y float)
begin
	declare mes interger;
    set mes = curdate();
    end $