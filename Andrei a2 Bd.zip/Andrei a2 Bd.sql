create database cuaprodMaisCaroMaisBaratoEstoque;
use cua;
create table produto(
id int not null auto_increment,
descricao varchar(100),
preco float,
estoque int,
situaçao char,
primary key(id)
);
insert into produto
(descricao, preco, estoque, situaçao)
values
('p1', '10.00', '10', 'd'),
('p2', '20.00', '0', 'i'),
('p3', '30.00', '30', 'd');
('p4', '40.00', '40', 'd')
Delimiter $
create procedure prodMaisCaroMaisBaratoEstoque(out pmaiscaro float,
											   out pmaisbarato float,
											   out numprodvendidos int)
begin
	select max(preco) into pmaiscaro from produto;
    select min(preco) into pmaisbarato from produto;
    select count(*) into numprodvendidos from produto;
    end $
Delimiter ;