create database Bdexercicio_17jun2020;
use Bdexercicio_17jun2020;
create table funcionario(
	id int not null auto_increment,
	nome varchar(100),
    salario float,
    categoria varchar(100),
    primary key(id)
);
insert into funcionario(nome,categoria,salario)
values ("Pedro","Professor","4000.00"),
("joana","Colaborador","2500.00"),
("Beatriz","Reitora","10500.00"),
("Ana","Cordenador","5500.00");
create view categoria_funcionarios
as select nome_categoria, salario from categoria_funcionario;
create view salariosB
as select nome_categoria, salario from categoria_funcionarios where salario > 5001 and salario <=10000;
create view salariosA
as select nome_categoria, salario from categoria_funcionarios where salario > 10000;
create view salariosC
as select nome_categoria, salario from categoria_funcionarios where salario > 3001 and salario <= 5000;
create view salariosD
as select nome,categoria, salario from categoria_funcionarios where salario > 1000 and salario <=3000;
select * from view salariosB;
select * from view salariosA;
select * from view salariosC;
select * from view salariosD;
drop database Bdexercicio_17jun2020

   
