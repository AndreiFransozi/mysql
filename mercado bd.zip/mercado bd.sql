create database mercado;
use mercado;
create table fornecedor(
id_fornecedor int not null auto_increment,
nome varchar(255),
cidade varchar(255),
primary key(id_fornecedor)
);
create table compra(
id_compra int not null auto_increment,
produto varchar(255),
tipo varchar(256),
quantidade int,
preco text,
primary key(id_compra)
);
create table cliente(
id_cliente int not null auto_increment,
nome varchar(255),
numerodocadastro float,
primary key(id_cliente)
);
create table funcionario(
id_funcionario int not null auto_increment,
nome_funcionario varchar(255),
função varchar (255),
primary key(id_funcionario)
);
insert into fornecedor
(nome, cidade)
values
('elma chips', 'Rio de janeiro'),
('pepsico', 'São Paulo'),
('Nestle', ''),
('Danone', ''),
('Ambev', ''),
('Nissin', ''),
('modelênz', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', '');
insert into compra
(produto, tipo, quantidade, preco)
values
("", "", "", ""),
("", "", "", "");
insert into cliente
(nome, numerodocadastro)
values
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', '');
insert into funcionario
(produto, tipo, quantidade, preco)
values
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", ""),
("", "", "", "");
