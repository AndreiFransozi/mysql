create database loja_carros;
use loja_carros;
create table carros(
id_carros int not null auto_increment,
marca varchar(255),
ano year,
modelo varchar(255),
preco decimal (9,2),
placa char(8),
primary key (id_carros)
);
create table comprador(
id_comprador int not null auto_increment,
nome varchar(255),
telefone text,
Cnh int,
primary key (id_comprador)
);
create table venda(
id_venda int not null auto_increment,
Cnh int,
marca varchar(255),
ano year,
modelo varchar(255),
preco_venda decimal(9,2),
placa char(8),
primary key (id_venda)
);
insert into carros
(marca, ano, modelo, preco, placa)
values
("Mitsubishhi", "2021", "L200 Triton Outdor", "149990.00", "MQT-2039"),
("Jeep", "2021", "Renegade Sport", "85590.00", "KFZ-7230"),
("Tesla", "2021", "Modelo y", "331200.00", "KFZ-7231"),
("Toyota", "2021", "COROLLA ALTIS HYBRID", "137990.00", "KFZ-7232"),
("Fiat", "2020", "Mobi", "44990.90", "KFZ-7233"),
("Fiat", "2020", "Argo Trekking 1.3", "51290.00", "KFZ-7234"),
("Fiat", "2020", "Cronos", "69990.00", "KFZ-7235"),
("Fiat", "2019", "Doblò", "98990.00", "KFZ-7236"),
("Fiat", "2020", "Ducato", "131490.00", "KFZ-7237"),
("Fiat", "2021", "Grand Siena", "55790.00", "KFZ-7238"),
("Fiat", "2021", "Strada", "79990.00", "KFZ-7239");
insert into comprador
(nome, telefone, Cnh)
values
("Alba", "999990000", "01324791850"),
("Alec", "199999999", "01324791854"),
("Alisha", "199999998", "01324791851"),
("Aloisio", "199999997", "01324791852"),
("Bento", "199999996", "01324791853"),
("Bruce", "199999995", "01324791855"),
("Hakim", "199999994", "01324791856"),
("Ézio", "199999993", "01324791857"),
("Francesco", "199999992", "01324791858"),
("Haya", "199999991", "01324791859"),
("Hendi", "199999990", "01324791860"),
("Henry", "999999999", "01324791861");
insert into venda
(Cnh, marca, ano, modelo, preco_venda, placa)
values
("01324791850", "Fiat", "2020", "Mobi", "44990.96", "KFZ-7233"),
("01324791851", "Fiat", "2020", "Argo Trekking 1.3", "51290.05", "KFZ-7234"),
("01324791852", "Fiat", "2020", "Cronos", "69990.07", "KFZ-7235"),
("01324791853", "Fiat", "2019", "Doblò", "98990.70", "KFZ-7236"),
("01324791854", "Fiat", "2020", "Ducato", "131490.50", "KFZ-7237"),
("01324791855", "Fiat", "2021", "Strada", "79990.04", "KFZ-7239"),
("01324791856", "Fiat", "2021", "Grand Siena", "55790.30", "KFZ-7238"),
("01324791857", "Tesla", "2021", "Modelo y", "331200.01", "KFZ-7231");

drop database loja_carros